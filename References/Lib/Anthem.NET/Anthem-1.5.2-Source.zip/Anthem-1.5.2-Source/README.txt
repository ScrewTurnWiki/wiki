Anthem.NET is a AJAX-ish toolkit for ASP.NET 1.1 and 2.0.

It should work with any browser that supports JavaScript, the
innerHTML property, and XMLHttpRequest.

It should also work with either Microsoft's CLR or the Mono Runtime
(version 1.1.12.1 or higher).

All of the code has been donated to the public domain.

Please subscribe to the mailing lists if you need any help:

http://anthem-dot-net.sourceforge.net/

If you find any bugs, please enter your bug reports using the
SourceForge tracker. Or, better yet, fix them and submit a patch.

We're always looking for more developers!

